# Instructions

This repository contains a simple application written in Go. Your task is to write an automated script that will deploy this application to a local Kubernetes cluster using [kind](https://kind.sigs.k8s.io/), [k3d](https://github.com/rancher/k3d) or [minikube](https://minikube.sigs.k8s.io/docs/start/)). This task is divided into parts with specific objectives.

To ensure fairness in our hiring process and to respect your time, there is a 3 hour time limit. You might not be able to finish all parts within this time limit, but you should checkpoint your work by making a Git commit after you are finished with each part. If you ever make tradeoffs due to the time limit, please document those in writing (e.g., "Normally I would do X, but to save time I am going to do Y for this exercise").

When you are finished (or after 3 hours), send us a compressed archive of your code (e.g., .zip, .tar.gz).

_You are allowed to lookup documentation and information on the internet, but all code should be written by you during the time you have been given to complete this assignment._

## Part 1 - Build

This application has two services (frontend, config) that are ready to build. Here are the Go commands that produce the relevant binaries:

```bash
go build -o frontend cmd/frontend/main.go
go build -o config cmd/config/main.go
```

You task is to create a single command (e.g., `docker build ...`, `./build.sh`) that a developer can run to build the application from source and produce the Docker image(s) necessary to run this application on a Kubernetes cluster. Document this command in the [README.md](README.md).

## Part 2 - Deploy

Write the Kubernetes YAML configuration that can be used to deploy this application to Kubernetes.

Requirements:

- The frontend service is a horizontally scalable stateless HTTP server that listens on `APP_FRONTEND_PORT`. It exposes a `/config` HTTP endpoint that delegates to the `config` services.
- The config service is a singleton stateful HTTP server that listens on `APP_CONFIG_PORT`. It exposes a `/file` endpoint that allows writing to and reading from `data.txt` located at `APP_DATA_PATH`. `APP_DATA_PATH` should be a location that persists even if the service restarts or the hardware node fails.
- You should also provide `APP_CONFIG_HOST` to the frontend to provide the hostname for the config service.

You are done with this part when you have added documentation to [README.md](README.md) that documents:

1. The minimum version of Kubernetes that is required. Prefer the default version of your Kubernetes cluster provider. If a different version is required, document the reason for choosing a different version (e.g., a newer Kubernetes version contains features that you are using in your solution).
2. A command that can be used to deploy the application to a Kubernetes cluster. This command may be a script that you write. If you decide to use any tooling aside from `kubectl`, document the required versions and the reasons for using that tooling.
3. How to make a HTTP request to the frontend service from the command line (e.g., by using `curl` or `httpie`).

## Part 3 - Versioning

It is possible to embed the version number in the Go binaries by passing an extra flag to the `go build`, like this:

```
go build -o frontend -ldflags "-X github.com/sourcegraph/coding-exercise-kubernetes/cmd/internal/binary.version=1.0.0" cmd/frontend/main.go
```

Update your solution from part 1 to set this version according to the following rules:

1. If there is a `git tag` that points to the commit being built and it looks like a [semver](https://semver.org/) then use that version.
2. Otherwise, generate a pseudo version (not semver) using a heuristic that you feel will be sufficient to identify a build. Document this scheme in the [README.md](README.md).
3. Update the code to return this information in a simple way (either via a CLI command like `--version` or via a debug http.Handler, there are many examples available for this).

## Part 4 - Writing a code host client

The frontend `/repository` endpoint pretends to be a black box code host that exposes a simple HTTP API. Your task will be to build a proxy service that calls this code host's HTTP API and exposes some additional features. You do not need to deploy this service to Kubernetes, but you are free to do so if it makes this part simpler. We just need the instructions on how to use the proxy with `curl`.

You might not have time to complete all tasks and that is OK. Do not move on to another part of the problem until you have a complete solution to the previous section and make sure to checkpoint your work with a git commit after each part.

### Part 4.1: Aggregation

The `/repository` endpoint returns a single random repository.

Your task is to create a new service with an endpoint (e.g. /repositories) that calls http://localhost:7080/repository and returns a JSON array of repositories.

Your endpoint should accept two query parameters:
- `count`:  Return this number of random repositories (default to 1).
- `unique`: Return count unique repositories if the value is true, else duplicates are allowed.

Fetching multiple repositories from the code host can be done concurrently to speed-up client requests but is not necessary and you can use the latency query parameter to customize the latency of the code host (e.g. http://localhost:7080/repository?latency=1s) and emulate a slow host if you whish to test it.

### Part 4.2: Error handling

Update your proxy to handle transient failures on the code host by retrying until the requirements of the request can be satisfied.

You can simulate a high failure rate on the code host by setting the failRatio query parameter (e.g. http://localhost:7080/repository?failRatio=0.7).
