# Coding exercise

If you are applying for a position at Sourcegraph, read [the instructions](INSTRUCTIONS.md). You
will add content to this README as you complete parts of the exercise.

If you are a Sourcegraph team member, send a zip of this directory to the candidate.
