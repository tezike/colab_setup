package main

import (
	"encoding/json"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"os/user"
	"path/filepath"

	"github.com/sourcegraph/coding-exercise-kubernetes/cmd/internal/env"
)

var configFile string

var port string

func main() {
	port := env.MustGet("APP_CONFIG_PORT")
	path := os.Getenv("APP_DATA_PATH")

	if path == "" {
		u, err := user.Current()
		if err != nil {
			panic(err)
		}
		path = u.HomeDir
	}
	configFile = filepath.Join(path, "data.txt")

	mux := http.NewServeMux()
	mux.HandleFunc("/file", handleFile)

	log.Printf("listening on :%s\n", port)
	log.Fatalln(http.ListenAndServe(":"+port, mux))
}

func handleFile(w http.ResponseWriter, r *http.Request) {
	if write := r.FormValue("write"); write != "" {
		if err := ioutil.WriteFile(configFile, []byte(write), 0644); err != nil {
			writeError(w, err)
			return
		}
	}
	b, err := ioutil.ReadFile(configFile)
	if err != nil {
		writeError(w, err)
		return
	}
	writeJSON(w, map[string]interface{}{
		"content": string(b),
	})
}

func writeJSON(w http.ResponseWriter, v interface{}) {
	w.Header().Set("Content-Type", "application/json")
	if err := json.NewEncoder(w).Encode(v); err != nil {
		panic(err)
	}
}

func writeError(w http.ResponseWriter, err error) {
	switch x := err.(type) {
	case *httpError:
		w.WriteHeader(x.status)
	default:
		w.WriteHeader(http.StatusInternalServerError)
	}
	writeJSON(w, map[string]string{
		"error": err.Error(),
	})
}

type httpError struct {
	status  int
	message string
}

func (err *httpError) Error() string {
	return err.message
}
