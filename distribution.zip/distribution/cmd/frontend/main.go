package main

import (
	"encoding/json"
	"fmt"
	"io"
	"log"
	"math/rand"
	"net/http"
	"os"
	"strconv"
	"time"

	"github.com/sourcegraph/coding-exercise-kubernetes/cmd/internal/env"
)

var fontendPort string
var configHost string
var configPort string

var colors = []string{
	"red",
	"orange",
	"yellow",
	"green",
	"indigo",
	"violet",
	"", // intentionally empty
}

type repository struct {
	ID        int       `json:"id,omitempty"`
	Name      string    `json:"name,omitempty"`
	FetchedAt time.Time `json:"fetchedAt,omitempty"`
}

var repositories []repository

func main() {
	fontendPort = env.MustGet("APP_FRONTEND_PORT")
	configHost = env.MustGet("APP_CONFIG_HOST")
	configPort = env.MustGet("APP_CONFIG_PORT")

	// Initialize more repositories than unique names, but keep the number small so that duplicates are frequent enough.
	// Candidate solutions should work for any number of repositories.
	for i := 0; i < 10; i++ {
		repositories = append(repositories, repository{
			ID:   i + 1,
			Name: colors[i%len(colors)],
		})
	}

	mux := http.NewServeMux()
	mux.HandleFunc("/", handleHello)
	mux.HandleFunc("/config", handleConfig)
	mux.HandleFunc("/repository", handleGetRepository)

	log.Printf("listening on :%s\n", fontendPort)
	if err := http.ListenAndServe(":"+fontendPort, mux); err != nil {
		log.Fatal(err)
	}
}

func handleHello(w http.ResponseWriter, r *http.Request) {
	host, _ := os.Hostname()
	w.Write([]byte("Hello from " + host))
	w.Write([]byte("\n"))
}

func handleConfig(w http.ResponseWriter, r *http.Request) {
	url := fmt.Sprintf("http://%s:%s", configHost, configPort)
	resp, err := http.Get(url + "/file?write=" + r.FormValue("write"))
	if err != nil {
		writeError(w, err)
		return
	}
	defer resp.Body.Close()
	if _, err := io.Copy(w, resp.Body); err != nil {
		writeError(w, err)
	}
	w.Write([]byte("\n"))
}

func handleGetRepository(w http.ResponseWriter, r *http.Request) {
	id := rand.Intn(len(repositories)) + 1
	repo := repositories[id-1]
	repo.FetchedAt = time.Now() // we are modifying a copy of the repo
	if err := misbehave(w, r, &repo); err != nil {
		writeError(w, err)
		return
	}
	writeJSON(w, map[string]interface{}{
		"repository": repo,
	})
}

func misbehave(w http.ResponseWriter, r *http.Request, repo *repository) error {
	latency := r.FormValue("latency")
	if latency == "" {
		latency = "500ms"
	}
	d, err := time.ParseDuration(latency)
	if err != nil {
		return err
	}
	time.Sleep(d)

	failRatio := r.FormValue("failRatio")
	if failRatio != "" {
		f, err := strconv.ParseFloat(failRatio, 64)
		if err != nil {
			return err
		}
		if rand.Float64() < f {
			switch rand.Intn(3) {
			case 0:
				r.Form.Set("panicRatio", "1")
			case 1:
				r.Form.Set("errorRatio", "1")
			case 2:
				r.Form.Set("garbageRatio", "1")
			default:
				panic("bug")
			}
		}
	}

	panicRatio := r.FormValue("panicRatio")
	if panicRatio != "" {
		f, err := strconv.ParseFloat(panicRatio, 64)
		if err != nil {
			return err
		}
		if rand.Float64() < f {
			panic("random panic!")
		}
	}

	errorRatio := r.FormValue("errorRatio")
	if errorRatio != "" {
		f, err := strconv.ParseFloat(errorRatio, 64)
		if err != nil {
			return err
		}
		if rand.Float64() < f {
			return &httpError{
				status:  http.StatusInternalServerError,
				message: "random error!",
			}
		}
	}

	garbageRatio := r.FormValue("garbageRatio")
	if garbageRatio != "" {
		f, err := strconv.ParseFloat(garbageRatio, 64)
		if err != nil {
			return err
		}
		if rand.Float64() < f {
			w.Write([]byte("random garbage!"))
		}
	}

	return nil
}

func writeJSON(w http.ResponseWriter, v interface{}) {
	w.Header().Set("Content-Type", "application/json")
	if err := json.NewEncoder(w).Encode(v); err != nil {
		panic(err)
	}
}

func writeError(w http.ResponseWriter, err error) {
	switch x := err.(type) {
	case *httpError:
		w.WriteHeader(x.status)
	default:
		w.WriteHeader(http.StatusInternalServerError)
	}
	writeJSON(w, map[string]string{
		"error": err.Error(),
	})
}

type httpError struct {
	status  int
	message string
}

func (err *httpError) Error() string {
	return err.message
}
